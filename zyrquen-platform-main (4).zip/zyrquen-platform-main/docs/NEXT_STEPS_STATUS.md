# สถานะงาน 7 ข้อ (ตรวจจริง ณ ตอนแพ็ค)

| # | งาน | สถานะ | หลักฐาน / ข้อจำกัด |
|---|---|---|---|
| 1 | download_model.py | ตรวจโค้ดแล้ว ไม่แก้ | ไม่ได้รัน (ต้องใช้เน็ต + huggingface_hub). หมายเหตุ: ดึง Qwen เพื่อทดสอบ runtime เท่านั้น ไม่ใช่โมเดลของ ZYRQUEN |
| 2 | .gitignore | เพิ่มกฎที่ขาด | เพิ่ม *.db, cache, checkpoints/, !.env.example (เดิม `.env.*` ซ่อน .env.example) |
| 3 | apps/api/Dockerfile | แก้ PYTHONPATH + ZYRQUEN_MODEL_PATH | ยังไม่ได้ docker build (ไม่มี Docker) |
| 4 | api-tests.yml | เพิ่ม PYTHONPATH | ตรวจ import resolution: ก่อนแก้ `apps.core` หาไม่เจอ, หลังแก้เจอ. ยังไม่ได้รัน pytest/Actions จริง |
| 5 | Cloud Deployment | ยังไม่ทำ | ต้องมีบัญชี/สิทธิ์ผู้ให้บริการคลาวด์ |
| 6 | PostgreSQL + Volume | เตรียม docker-compose.yml + .env.example | ยังไม่ได้รัน; ยังไม่มี migration/สร้างตาราง (alembic อยู่ใน requirements แต่ไม่มีโค้ด) |
| 7 | Native Model Architecture | เขียน apps/core/native (config, model, tests) | ยังไม่ได้รัน เพราะไม่มี torch ในสภาพแวดล้อม; compile ผ่านเท่านั้น |

ข้อสังเกต: `model_loader.py` ใช้ torch + transformers แต่ไม่อยู่ใน requirements.txt จึงจะ degraded เสมอจนกว่าจะเพิ่ม

## Phase 3 progress
| ขั้น | สถานะ | หลักฐาน |
|---|---|---|
| 3.1 Model Architecture | เขียนแล้ว ยังไม่ได้รันเทสต์ | ไม่มี torch ในสภาพแวดล้อมที่แพ็ค |
| 3.2 Native Tokenizer | เสร็จ + ทดสอบแล้ว | `apps/core/native/tokenizer.py` (byte-level BPE, stdlib ล้วน) 14 เทสต์ผ่านด้วย runner ชั่วคราว (ไม่มี pytest ในที่แพ็ค); เพิ่ม step ใน CI แล้วแต่ยังไม่เคยรันบน Actions |
| 3.3 Dataset Preparation | เสร็จ + ทดสอบแล้ว | `apps/core/native/dataset.py` (stdlib): import jsonl/txt, clean, redact PII แบบ pattern, กรองคุณภาพ, ตรวจภาษา (heuristic), ตัดซ้ำแบบตรงตัว, split แบบ deterministic, manifest + SHA-256 + บังคับระบุ licence; 11 เทสต์ผ่าน (runner ชั่วคราว) |
| 3.4 Training Pipeline | เขียนแล้ว ส่วนที่ไม่ใช้ torch ทดสอบแล้ว | `train.py`: LR schedule, batch sampling, token stream ผ่าน 4 เทสต์; **ลูปฝึกจริง (`train()`) ยังไม่เคยรัน** — `test_train_torch.py` เขียนไว้แต่ต้องมี torch |
| 3.5 Checkpoint Registry | ยังไม่ได้ทำ (ใช้ CheckpointManager ของ Phase 4 ไปก่อน) | |
| 3.6 Evaluation Engine | ยังไม่ได้ทำ (มีแค่ val loss/perplexity ใน train()) | |

ข้อจำกัด 3.3: ตัดซ้ำเฉพาะข้อความเหมือนกันเป๊ะ (ไม่มี near-duplicate); PII redaction ไม่จับชื่อ/ที่อยู่; licence เป็นคำที่ผู้ใช้ประกาศ ไม่ใช่การตรวจทางกฎหมาย

หมายเหตุ 3.2: โค้ดฝึก vocabulary จาก corpus ที่ส่งเข้าไปเท่านั้น ยังไม่ได้ฝึกกับ Dataset จริง (ยังไม่มี Dataset) จึงยังไม่มีไฟล์ tokenizer.json จริง

## Phase 4 progress (เริ่มก่อน Phase 3 ผ่านครบ ตามที่ผู้ใช้สั่ง)
| ขั้น | โมดูล | สถานะ |
|---|---|---|
| 4.1 GPU Provisioning | gpu/resource_manager.py, provisioner.py | ตรวจ GPU ผ่าน nvidia-smi + LocalProvider เทสต์ด้วยเอาต์พุตจำลอง; **ยังไม่มี adapter เช่า/ปิด GPU บนคลาวด์** (ต้องมีบัญชี/คีย์ผู้ให้บริการ) |
| 4.2 Distributed | distributed/trainer.py | อ่านค่า RANK/WORLD_SIZE (เทสต์แล้ว); init/shutdown process group เขียนแล้วแต่**ยังไม่ได้ทดสอบ** (ต้อง torch + GPU). ยังไม่มีลูปฝึก (อยู่ใน 3.4) |
| 4.3 Checkpoint Recovery | recovery/checkpoint_recovery.py | บันทึกแบบ atomic + SHA-256, ข้ามไฟล์เสีย, ลบของเก่า เทสต์แล้วด้วย serializer แบบ JSON; **torch.save/load ตัวจริงยังไม่ได้ทดสอบ** |
| 4.4 Monitoring | monitoring/training_monitor.py | JSONL metrics + ตรวจ loss diverge เทสต์แล้ว; ยังไม่เก็บ GPU metrics จริง |
| 4.5 Cost Control | cost/cost_controller.py | จำกัด runtime/GPU-hours/งบ เทสต์แล้ว (นาฬิกาจำลอง) |
| 4.6 Validation | validation/model_validator.py | ตรวจความสมบูรณ์ checkpoint + เกณฑ์ val_loss/perplexity เทสต์แล้ว |

เกณฑ์ผ่าน Phase 4 "ฝึกบน Cloud GPU ได้จริง" **ยังไม่ผ่าน** — ยังไม่เคยฝึกโมเดลบน GPU.
